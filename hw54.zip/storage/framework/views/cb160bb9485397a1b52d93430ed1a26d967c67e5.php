<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Авторы</h1>
    <div class="container overflow-hidden text-center mt-5">
        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-5 mx-3" style="width: 20rem; display: inline-block">
                <div class="card-body">
                    <?php if(!is_null($author->picture)): ?>
                        <img class="card-img-top" height="300px" src="<?php echo e(asset('storage/' . $author->picture)); ?>"
                             alt="<?php echo e($author->picture); ?>">
                    <?php else: ?>
                        <h2>Фото не загружено</h2>
                    <?php endif; ?>
                    <h1 class="text-start ">
                        <a href="<?php echo e(route('authors.show', ['author'=> $author])); ?>">
                            <?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?>

                        </a>
                    </h1>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw49/resources/views/client/authors/index.blade.php ENDPATH**/ ?>