<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3><a href="<?php echo e(route('books.index')); ?>">Главная ></a>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('genres.show', ['genre' => $genre])); ?>">
                <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($bg->id == $genre->id): ?>
                <?php echo e($genre->name); ?> >
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($book->name); ?>

        </h3>
        <h2> Автор:
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('authors.show', ['author' => $author])); ?>">
                    <?php if($author->id == $book->author_id): ?>
                        <?php echo e($book->author->first_name); ?> <?php echo e($book->author->last_name); ?>

                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h2>
        <h2> Наименование книги:
            <?php echo e($book->name); ?></h2>
        <?php if(!is_null($book->picture)): ?>
            <img
                 src="<?php echo e(asset('storage/' . $book->picture)); ?>"
                 alt="<?php echo e($book->picture); ?>">
        <?php else: ?>
            <h4>Нет фотографии</h4>
        <?php endif; ?>
        <h3 class="card_title">Цена: <?php echo e($book->price); ?> сом</h3>
        <h4 class="card-title">Описание: <?php echo e($book->description); ?></h4>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw49/resources/views/client/books/show.blade.php ENDPATH**/ ?>