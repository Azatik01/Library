<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Book store</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>


</head>
<body>
<div class="container text-center mt-5 text-success">
    <h1>Книжный магазин "Раритет"</h1>
</div>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH /home/elchibek/php_main/hw49/resources/views/layouts/client.blade.php ENDPATH**/ ?>