<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-2 g-4">
        <div class="col">
            <div class="card text-bg-dark mb-3" style="width: 25rem;">
                <?php if(!is_null($book->picture)): ?>
                    <img class="card-img-top" src="<?php echo e(asset('storage/' . $book->picture)); ?>" alt="<?php echo e($book->picture); ?>">
                <?php else: ?>
                    <h2>Фото не загружено</h2>
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title">Наименование: <?php echo e($book->name); ?></h5>
                    <h5 class="card-title">Описание: <?php echo e($book->description); ?></h5>
                        <h5 class="card-title">Автор:<?php echo e($book->author->first_name); ?> <?php echo e($book->author->last_name); ?></h5>
                    <h5>Жанр: </h5>
                    <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h5 class="card-title"><?php echo e($genre->name); ?></h5>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="card-title">Цена: <?php echo e($book->price); ?></h5>
                </div>
            </div>
            <button class="btn btn-warning">
                <a href="<?php echo e(route('admin.books.index')); ?>">Назад</a>
            </button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw49/resources/views/admin/books/show.blade.php ENDPATH**/ ?>