<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Жанры</h1>
    <div class="container overflow-hidden text-center mt-5">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-5 mx-3" style="width: 18rem;display: inline-block">
                <div class="card-body">
                    <?php if(!is_null($genre->picture)): ?>
                        <img class="card-img-top" height="300px" src="<?php echo e(asset('storage/' . $genre->picture)); ?>"
                             alt="<?php echo e($genre->picture); ?>">
                    <?php else: ?>
                        <h2>Фото не загружено</h2>
                    <?php endif; ?>
                    <h1 class="text-start ">
                        <a href="<?php echo e(route('genres.show', ['genre'=> $genre])); ?>">
                            <?php echo e($genre->name); ?>

                        </a>
                    </h1>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw54/resources/views/client/genres/index.blade.php ENDPATH**/ ?>