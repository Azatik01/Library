<?php $__env->startSection('content'); ?>
        <div class="text-center">
            <h1 class="text" style="display: inline-block">Список жанров</h1>
            <div class="mt-3 mx-3" style="display: inline-block">
                <button type="submit" class="btn btn-outline-primary">
                    <a href="<?php echo e(route('admin.genres.create')); ?>">
                        Добавить
                    </a>
                </button>
            </div>
        </div>
        <div class="container">
        <div class="row mt-5 pb-5">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Наименование</th>
                    <th scope="col">Описание</th>
                    <th scope="col">Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($genre->name); ?></td>
                        <td><?php echo e($genre->description); ?></td>
                        <td>
                            <button class="btn btn-warning" style="display: inline-block">
                                <a href="<?php echo e(route('admin.genres.edit', ['genre' => $genre])); ?>">
                                    Изменить
                                </a>
                            </button>
                            <form action="<?php echo e(route('admin.genres.destroy', ['genre' => $genre])); ?>" method="post" style="display: inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" style="display: inline-block">
                                Удалить
                                </button>
                            </form>
                            <button class="btn btn-success" style="display: inline-block">
                                <a href="<?php echo e(route('admin.genres.show', ['genre' => $genre])); ?>">
                                    Просмотреть
                                </a>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw54/resources/views/admin/genres/index.blade.php ENDPATH**/ ?>