<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Книги</h1>
    <div class="container overflow-hidden text-center mt-5">
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-5 mx-3" style="width: 18rem; display: inline-block">
                <div class="card-body">
                    <?php if(!is_null($book->picture)): ?>
                        <img class="card-img-top" src="<?php echo e(asset('storage/' . $book->picture)); ?>"
                             alt="<?php echo e($book->picture); ?>">
                    <?php else: ?>
                        <h2>Фото не загружено</h2>
                    <?php endif; ?>
                    <h1 class="text-start ">
                        <a href="<?php echo e(route('books.show', ['book'=> $book])); ?>">
                            <?php echo e($book->name); ?>

                        </a>
                    </h1>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw55/resources/views/client/books/index.blade.php ENDPATH**/ ?>