<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="text" style="display: inline-block">Список авторов</h1>
        <div class="mt-3 mx-3" style="display: inline-block">
            <button type="submit" class="btn btn-outline-primary">
                <a href="<?php echo e(route('admin.authors.create')); ?>">
                    Добавить
                </a>
            </button>
        </div>
    </div>
    <div class="container">
        <div class="row mt-5 pb-5">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Имя</th>
                    <th scope="col">Фамилия</th>
                    <th scope="col">Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($author->first_name); ?></td>
                        <td><?php echo e($author->last_name); ?></td>
                        <td>
                            <button class="btn btn-warning" style="display: inline-block">
                                <a href="<?php echo e(route('admin.authors.edit', ['author' => $author])); ?>">
                                    Изменить
                                </a>
                            </button>
                            <form action="<?php echo e(route('admin.authors.destroy', ['author' => $author])); ?>" method="post" style="display: inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" style="display: inline-block">
                                    Удалить
                                </button>
                            </form>
                            <button class="btn btn-success" style="display: inline-block">
                                <a href="<?php echo e(route('admin.authors.show', ['author' => $author])); ?>">
                                    Просмотреть
                                </a>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw54/resources/views/admin/authors/index.blade.php ENDPATH**/ ?>