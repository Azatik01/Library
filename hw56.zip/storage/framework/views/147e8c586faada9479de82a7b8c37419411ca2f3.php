<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-2 g-4">
        <div class="col">
            <div class="card text-bg-dark mb-3" style="width: 25rem;">
                <?php if(!is_null($author->picture)): ?>
                    <img class="card-img-top" src="<?php echo e(asset('storage/' . $author->picture)); ?>" alt="<?php echo e($author->picture); ?>">
                <?php else: ?>
                    <h2>Фото не загружено</h2>
                <?php endif; ?>
                <div class="card-body" >
                    <h5 class="card-title">Имя: <?php echo e($author->first_name); ?></h5>
                    <h5 class="card-title">Фамилия: <?php echo e($author->last_name); ?></h5>
                    <h5 class="card-title">Описание: <?php echo e($author->description); ?></h5>
                </div>
            </div>
            <button class="btn btn-warning">
                <a href="<?php echo e(route('admin.authors.index')); ?>">Назад</a>
            </button>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw49/resources/views/admin/authors/show.blade.php ENDPATH**/ ?>