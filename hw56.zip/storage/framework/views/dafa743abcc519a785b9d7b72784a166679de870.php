<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <h3><a href="<?php echo e(route('authors.index')); ?>">Главная ></a> <?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?></h3>
        <h2 class="text-warning"><?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?></h2>
        <div class="card mb-3">
            <?php if(!is_null($author->picture)): ?>
                <img class="card-img-top" style="width: 350px; height: 350px"
                     src="<?php echo e(asset('storage/' . $author->picture)); ?>"
                     alt="<?php echo e($author->picture); ?>">
            <?php else: ?>
                <h4>Нет фотографии</h4>
            <?php endif; ?>
            <div class="card-body">
                <h4 class="card-text"><?php echo e($author->description); ?></h4>
            </div>
        </div>
    </div>

    <div class="container pt-5">
        <h3>
            Книги автора <?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?>

        </h3>
        <?php $__currentLoopData = $array_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mx-5 mt-3" style="width: 18rem; display: inline-block">
                <div class="card-body">
                    <?php if(!is_null($book->picture)): ?>
                        <img class="card-img-top" height="300px" src="<?php echo e(asset('storage/' . $book->picture)); ?>"
                             alt="<?php echo e($book->picture); ?>">
                    <?php else: ?>
                        <h2>Фото не загружено</h2>
                    <?php endif; ?>
                    <h5 class="card-title">Название:
                        <a href="<?php echo e(route('books.show', ['book' => $book])); ?>">
                            <?php echo e($book->name); ?>

                        </a>
                    </h5>
                    <h5 class="card-title">Автор:
                        <a href="<?php echo e(route('authors.show', ['author' => $author])); ?>">
                            <?php echo e($author->first_name); ?> <?php echo e($author->last_name); ?>

                        </a>
                    </h5>
                    <h5 class="card-title">
                        Цена: <?php echo e($book->price); ?> сом
                    </h5>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw56/resources/views/client/authors/show.blade.php ENDPATH**/ ?>