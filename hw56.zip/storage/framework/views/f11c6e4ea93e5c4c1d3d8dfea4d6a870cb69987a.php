<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <h1 class="text" style="display: inline-block">Список книг</h1>
        <div class="mt-3 mx-3" style="display: inline-block">
            <button type="submit" class="btn btn-outline-primary">
                <a href="<?php echo e(route('admin.books.create')); ?>">
                    Добавить
                </a>
            </button>
        </div>
    </div>
    <div class="container">
        <div class="row mt-5 pb-5">
            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Название книги</th>
                    <th scope="col">Автор</th>
                    <th scope="col">Жанр</th>
                    <th scope="col">Цена</th>
                    <th scope="col">Действия</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($book->name); ?></td>
                        <td><?php echo e($book->author->first_name); ?> <?php echo e($book->author->last_name); ?></td>
                        <td>
                            <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($genre->name); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td><?php echo e($book->price); ?> сом</td>
                        <td>
                            <button class="btn btn-warning" style="display: inline-block">
                                <a href="<?php echo e(route('admin.books.edit', ['book' => $book])); ?>">
                                    Изменить
                                </a>
                            </button>
                            <form action="<?php echo e(route('admin.books.destroy', ['book' => $book])); ?>" method="post"
                                  style="display: inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger" style="display: inline-block">
                                    Удалить
                                </button>
                            </form>
                            <button class="btn btn-success" style="display: inline-block">
                                <a href="<?php echo e(route('admin.books.show', ['book' => $book])); ?>">
                                    Просмотреть
                                </a>
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw55/resources/views/admin/books/index.blade.php ENDPATH**/ ?>