<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3><a href="<?php echo e(route('books.index')); ?>">Главная ></a>
            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('genres.show', ['genre' => $genre])); ?>">
                    <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($bg->id == $genre->id): ?>
                            <?php echo e($genre->name); ?> -
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            >
            <?php echo e($book->name); ?>

        </h3>
        <h2> Автор:
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('authors.show', ['author' => $author])); ?>">
                    <?php if($author->id == $book->author_id): ?>
                        <?php echo e($book->author->first_name); ?> <?php echo e($book->author->last_name); ?>

                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </h2>
        <h2> Наименование книги:
            <?php echo e($book->name); ?></h2>
        <?php if(!is_null($book->picture)): ?>
            <img
                src="<?php echo e(asset('storage/' . $book->picture)); ?>"
                alt="<?php echo e($book->picture); ?>">
        <?php else: ?>
            <h4>Нет фотографии</h4>
        <?php endif; ?>
        <h3 class="card_title">Цена: <?php echo e($book->price); ?> сом</h3>
        <h4 class="card-title">Описание: <?php echo e($book->description); ?></h4>
    </div>
    <div class="container">
        <br>
    <h3>Комментарии: </h3>
    <div class="row">
        <button class="btn btn-primary" id="fadetoggle">Посмотреть комментарии</button>
        <div class="col-8 scrollit">
            <?php $__currentLoopData = $book->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="">
                    <div class="media g-mb-30 media-comment">
                        <div class="media-body u-shadow-v18 g-bg-secondary g-pa-30">
                            <div class="g-mb-15">
                                <h5 class="h5 g-color-gray-dark-v1 mb-0"><?php echo e($comment->author); ?></h5>
                                <h5 class="h5 g-color-gray-dark-v1 mb-0"><?php echo e($comment->rating); ?></h5>
                                <span class="g-color-gray-dark-v4 g-font-size-12"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                            </div>
                            <p>
                                <?php echo e($comment->description); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-4 fixed">
            <div class="comment-form">
                <form id="create-comment">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="book_id" value="<?php echo e($book->id); ?>">
                    <div class="form-group" id="authorName">
                        <label for="authorInput">Author</label>
                        <input name="author" type="text" class="form-control" id="authorInput" aria-describedby="authorHelpText"
                               required>
                        <small id="authorHelpText" class="form-text text-muted">You need to enter your full name.</small>
                    </div>
                    <div class="form-group" id="formRating">
                        <label for="authorRating" id="authorRating">
                            <select name="rating" id="rating">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
                        </label>
                    </div>
                    <div class="form-group" id="authorDescription">
                        <label for="authorDescription">Comment</label>
                        <textarea name="description" class="form-control" id="commentFormControl" rows="3" required></textarea>
                    </div>
                    <div class="text-center">
                        <button id="create-comment-btn" type="submit" class="mt-3 btn btn-outline-primary btn-sm btn-block">Add new
                            comment
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw55/resources/views/client/books/show.blade.php ENDPATH**/ ?>