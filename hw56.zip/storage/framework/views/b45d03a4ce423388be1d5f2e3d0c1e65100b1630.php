<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-2 g-4">
        <div class="col">
            <div class="card text-bg-dark mb-3" style="width: 25rem;">
                <?php if(!is_null($genre->picture)): ?>
                    <img class="card-img-top" src="<?php echo e(asset('storage/' . $genre->picture)); ?>"
                         alt="<?php echo e($genre->picture); ?>">
                <?php else: ?>
                    <h2>Фото не загружено</h2>
                <?php endif; ?>
            </div>
            <div class="container">
                <h3>
                    Книги в жанре: <?php echo e($genre->name); ?>

                </h3>
                <?php $__currentLoopData = $array_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($book->name); ?></h5>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="btn btn-warning">
                <a href="<?php echo e(route('admin.genres.index')); ?>">Назад</a>
            </button>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw49/resources/views/admin/genres/show.blade.php ENDPATH**/ ?>