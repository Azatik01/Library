<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <h3><a href="<?php echo e(route('genres.index')); ?>">Главная ></a> <?php echo e($genre->name); ?></h3>
        <h2 class="text-warning"><?php echo e($genre->name); ?></h2>
        <div class="card mb-3">
            <?php if(!is_null($genre->picture)): ?>
                <img class="card-img-top" style="width: 350px; height: 350px"
                     src="<?php echo e(asset('storage/' . $genre->picture)); ?>"
                     alt="<?php echo e($genre->picture); ?>">
            <?php else: ?>
                <h4>Нет фотографии</h4>
            <?php endif; ?>

            <div class="card-body">
                <h4 class="card-text"><?php echo e($genre->description); ?></h4>
            </div>
        </div>
    </div>

    <div class="container pt-5">
        <h3>
            Книги в жанре <?php echo e($genre->name); ?>

        </h3>
        <?php $__currentLoopData = $array_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mx-5 mt-5" style="width: 20rem; display: inline-block">
                    <div class="card-body">
                        <?php if(!is_null($book->picture)): ?>
                            <img class="card-img-top" height="300px" src="<?php echo e(asset('storage/' . $book->picture)); ?>"
                                 alt="<?php echo e($book->picture); ?>">
                        <?php else: ?>
                            <h2>Фото не загружено</h2>
                        <?php endif; ?>
                        <h5 class="card-title">Название:
                            <a href="<?php echo e(route('books.show', ['book' => $book])); ?>">
                                <?php echo e($book->name); ?>

                            </a>
                        </h5>
                        <h5 class="card-title">Автор:
                            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('authors.show', ['author' => $author])); ?>">
                                <?php if($author->id == $book->author->id): ?>
                                <?php echo e($book->author->first_name); ?> <?php echo e($book->author->last_name); ?>

                                    <?php endif; ?>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </h5>
                    </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/elchibek/php_main/hw49/resources/views/client/genres/show.blade.php ENDPATH**/ ?>