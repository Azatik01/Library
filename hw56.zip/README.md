<h1>Library</h1>
<h3>In this project, functionality was added for the admin and user. The difference between the functionality is that the administrator has access to deleting, adding and changing. It uses an acronym CRUD</h3>
